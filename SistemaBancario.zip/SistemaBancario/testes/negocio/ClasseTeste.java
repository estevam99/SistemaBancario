package negocio;
/* Teste de Classe Aluno XXX */
public class ClasseTeste {

}
